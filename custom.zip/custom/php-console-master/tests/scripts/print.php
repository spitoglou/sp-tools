<?php

echo $string;
