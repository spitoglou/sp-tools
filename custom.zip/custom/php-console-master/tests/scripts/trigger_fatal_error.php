<?php

undefined();
