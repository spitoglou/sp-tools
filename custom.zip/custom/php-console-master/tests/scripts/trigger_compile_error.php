<?php

require_once('not-exists');
