<?php

PhpConsole\Handler::getInstance()->start();
