// test local JS source file & line detection
undefinedFunc();
